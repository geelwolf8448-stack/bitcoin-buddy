# Bitcoin Buddy — pre-launch website package

This is a static HTML prototype designed to be tested on mobile and desktop.

## Included
- `index.html` — app interface, hypothetical calculator, local portfolio estimate, educational guides and locally stored price alerts.
- `privacy.html` — pre-launch privacy notice template; must be reviewed and completed.
- `terms.html` — pre-launch terms template; must be reviewed and completed.

## Important before public or commercial launch
1. The current browser prototype calls a public CoinGecko endpoint. Do not assume this permits commercial use. Confirm the provider's current plan, attribution and usage terms or replace the endpoint with a properly licensed data provider.
2. Replace the placeholder contact address and complete the operator details in the privacy and terms pages.
3. Test the app on multiple mobile browsers. Alerts only run while the page is open and successful price checks occur; they are not guaranteed or background push notifications.
4. This prototype has no server, user accounts, subscription billing, secure backend, analytics, or production monitoring.
5. Do not add wallet private keys, recovery phrases, exchange credentials or custody/trading functionality.
6. Get appropriate legal/compliance advice before introducing paid financial features or offering regulated crypto-asset services in any market.

## Quick local test
Open `index.html` in a browser with an internet connection. Price data may fail when the API blocks local-file requests, rate limits requests or changes access rules. The calculator and educational sections can still be tested.

## Publish as a static site
A hosting account and repository connection are needed to publish a public URL. One simple route is GitHub Pages:
1. Create or choose a GitHub repository.
2. Upload the files in this folder to the repository root.
3. In repository Settings → Pages, select deployment from the main branch and root folder (if available for the account/repository).
4. Wait for GitHub to provide the published URL, then open it on a phone and test it.

Do not share a public launch link until the placeholder contact information and data licensing are resolved. GitHub Pages settings and availability may vary by account and repository visibility.
