# Bitcoin Buddy

A lightweight static MVP for a beginner-friendly Bitcoin education website.

## Files
- `index.html` — landing page, indicative BTC price widget, BTC value calculator, beginner safety content
- `privacy.html` — initial privacy policy draft
- `terms.html` — initial terms of use draft

## Preview
Open `index.html` in a browser. The live price requires an internet connection and access to CoinGecko's public API. If the API is unavailable, the page shows an unavailable message rather than inventing a price.

## Publish with GitHub Pages
1. Upload all three HTML files to the root of the `main` branch in the `bitcoin-buddy` repository.
2. Open repository **Settings** → **Pages**.
3. Under build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Wait for the Pages deployment to finish and test the provided URL on a phone.

## Before monetisation
Add a real contact address, review the legal pages, add a clear privacy notice for any analytics or advertising, and only integrate reputable monetisation providers after checking eligibility and policy requirements. Revenue is not guaranteed. This MVP does not accept money, hold crypto or execute trades.
