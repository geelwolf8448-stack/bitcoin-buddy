# Bitcoin Buddy

A mobile-friendly Bitcoin education and practice website for beginners, starting in South Africa.

Features:
- Indicative BTC/ZAR and BTC/USD price from CoinGecko's public API.
- Rand-to-Bitcoin calculator.
- Local-only simulated practice amount.
- Beginner education and scam-safety tips.
- Privacy policy and terms pages.

## Publish with GitHub Pages
1. Open repository **Settings**.
2. Open **Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then save.
5. Wait for deployment and open the URL shown on the Pages settings page.

The individual HTML files must be in the root folder. GitHub Pages does not automatically extract ZIP archives. This is an educational tool only and does not promise earnings or provide financial advice.
